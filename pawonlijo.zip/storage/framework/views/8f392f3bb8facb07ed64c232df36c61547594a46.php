<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/admin/sales.blade.php */ ?>
<?php $__env->startSection('css'); ?>
	<style>
		#table th, #table td{
			font-size: 0.8rem;
			padding: 0.5rem !important;
			height: 2.5rem;
		}
		.info td, .info th{
			height: 3rem;
		}
		input[readonly]{
			background-color: white;
		}
		p{
			margin: 0;
		}
		.popover{
			width:40%;
			height:60%;
			max-width:none;
		}
	</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>	
	<div class="page-inner">
		<div class="page-header">
			<h4 class="page-title">Data Penjualan PawonLijo</h4>
			<ul class="breadcrumbs">
				<li class="nav-home">
					<a href="<?php echo e(route('admin.dashboard')); ?>">
						<i class="flaticon-home"></i>
					</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a>Data Penjualan</a>
				</li>
			</ul>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-body">
						<div class="row">
							<div class="col-md-12">
								<div class="card border shadow-none">
									<div class="card-body">
										<div class="row">
											<div class="col-md-10">
												<h5><h4 clas><i class="fas fa-info-circle mr-2 text-primary"></i><b>PENJUALAN TAHUN 2019</b></h4></h5>
											</div>

										</div>
										
										<div class="chart-container mt-4" style="height:60vh;">
											<canvas id="ProdukTransaksiTahun"></canvas>
										</div>
									</div>
								</div>
							</div>
						</div>
						<div class="card border shadow-none" id="data-transaksi">
							<div class="card-body">
								<div class="row">
									<div class="col-md-12 mb-4">
										<form action="/admin/sales#data-transaksi" method="GET">
										<div class="row">
											<div class="col-md-3 offset-md-2">
												<select name="id_booth" class="form-control" style="border-color: grey">
													<option value="">Semua</option>
													<?php $__currentLoopData = $booths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($booth->id_booth); ?>" <?php echo e($id_booth == $booth->id_booth ? 'selected' : null); ?>><?php echo e($booth->nama_booth); ?>, <?php echo e($booth->kota_booth); ?> </option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</select>
											</div>
											<div class="col-md-2 ">
												<select name="bulan" class="form-control" style="border-color: grey">
													<?php
														$i=1;
													?>
													<?php $__currentLoopData = NamaBulan(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $n => $nama): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($n); ?>" <?php echo e($b == $n ? 'selected':null); ?>><?php echo e($nama); ?> </option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</select>
											</div>
											<div class="col-md-2">
												<select name="tahun" class="form-control" style="border-color: grey">
													<?php for($a=2016; $a < 2027; $a++): ?>
														<option value="<?php echo e($a); ?>" <?php echo e($t == $a ? 'selected':null); ?>><?php echo e($a); ?></option>
													<?php endfor; ?>
												</select>
											</div>
											<div class="col-md-1">
												<input type="submit" name="filter" value="Submit" class="btn btn-sm btn-primary mt-1">
											</div>
										</div>
										</form>
									</div>
									<?php if(count($sales) != null): ?>
									<div class="col-md-12" id="filter">
										<div class="card shadow-none full-height">
											<div class="card-body">
												<h4 class="fw-bold" align="center">TRANSAKSI</h4>
												<div class="d-flex flex-wrap justify-content-around pb-2 pt-4">
													<?php
														$x = 0;
														$xy = 0;
														$jt = 0;
													?>
													<?php $__currentLoopData = $jumlah_t; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<div class="px-2 pb-2 pb-md-0 text-center">
															<div id="circles-<?php echo e($j->jenis); ?>"></div>
															<h6 class="fw-bold mt-3 mb-0"><?php echo e($j->jenis); ?></h6>
															<h6 class="fw-bold mb-0">Income : <?php echo e($j->total/1000); ?> K</h6>
														</div>
														<?php
															$x += $j->total/1000;
															$xy += $j->t_pajak/1000;
															$jt += $j->jumlah;
														?>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
													<div style="">
														<h4><b>INCOME : Rp <?php echo e($x); ?> K</b></h4>
														<h4><b>PAJAK : Rp <?php echo e($xy); ?> K</b></h4>
														<h4><b>TRANSAKSI : <?php echo e($jt); ?></b></h4>
													</div>
												</div>

											</div>
										</div>
									</div>
									<div class="col-md-12">
										<div class="table-responsive">
											<table class="table table-striped transaksi" id="table">
												<thead class="bg-warning text-light">
													<tr>
														<th>TANGGAL</th>
														<th>ID TRANSAKSI</th>
														<th>JENIS (PAJAK)</th>
														<th>KODE</th>
														<th>TOTAL</th>
														<th>DISCOUNT</th>
														<th>PAJAK</th>
														<th>TOTAL BERSIH</th>
														<th>DETAIL</th>
													</tr>
												</thead>
												<tbody>
													<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<tr>
														<td><?php echo e(date('d/m/Y H:i',strtotime($sale->created_at))); ?></td>
														<td><?php echo e($sale->id); ?></td>
														<td>
															<?php echo e($sale->jenis); ?> 
															(<?php echo e($sale->pajak); ?>%)
														</td>
														<?php if($sale->kode != null): ?>
														<td><?php echo e($sale->kode); ?></td>
														<?php else: ?>
														<td>-</td>
														<?php endif; ?>
														<td>Rp <?php echo e(Rupiahd($sale->subtotal)); ?></td>
														<td>Rp <?php echo e(Rupiahd($sale->potongan)); ?></td>
														<td>Rp <?php echo e(Rupiahd($sale->total_pajak)); ?></td>
														<td>Rp <?php echo e(Rupiahd($sale->total_bersih)); ?></td>
														<td><a href="<?php echo e(route('admin.sales-detail',$sale->id)); ?>" class="btn btn-primary btn-xs">Detail</a></td>
													</tr>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</tbody>
											</table>
										</div>
									</div>
									<?php else: ?>
									<div class="col-md-12">
										<div class="text-center">
											<h4 class="m-4">Tidak ada data untuk hasil pencarian ini</h4>
										</div>
									</div>
									<?php endif; ?>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
	<script src="<?php echo e(asset('assets/atlantis/js/plugin/chart-js/chart.min.js')); ?> "></script>

	<script>
		var ProdukTransaksiTahun = document.getElementById('ProdukTransaksiTahun').getContext('2d');

		var myProdukTransaksiTahun = new Chart(ProdukTransaksiTahun, {
			type: 'line',
			data: {
				labels: ["Jan", "Feb", "Mar", "Apr", "Mei", "Jun", "Jul", "Agu", "Sep", "Okt", "Nov", "Des"],
				datasets : [
					<?php
					$a = 0;
					$s = 0;
					$c = 0;
					$d = 0;
					$color = ['red','blue','green','purple','grey','orange','pink']
				?>
				<?php $__currentLoopData = $booths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					{
						label: "<?php echo e($b->nama_booth); ?>",
						borderColor: "<?php echo e($color[$c++]); ?>",
						pointBorderColor: "#FFF",
						pointBackgroundColor: "<?php echo e($color[$s++]); ?>",
						pointBorderWidth: 2,
						pointHoverRadius: 4,
						pointHoverBorderWidth: 1,
						pointRadius: 4,
						backgroundColor: 'transparent',
						fill: true,
						borderWidth: 2,
						data: [<?php echo e(implode(',',$ct[$a++])); ?>]
					},
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				]
			},
			options : {
				responsive: true, 
				maintainAspectRatio: false,
				legend: {
					position: 'bottom',
					labels : {
						padding: 20,
						fontColor: 'black',
						fontSize: 12
					}
				},
				tooltips: {
					mode: 'index',
					intersect: false,
					callbacks: {
	                    label: function(tooltipItems, data) { 
	                        return 'Income : Rp '+ tooltipItems.yLabel + ' K';
	                    }
	                }
				},
				hover: {
					mode: 'nearest',
					intersect: true
				},
				scales: {
			        yAxes: [{
			            beginAtZero:true,
		                ticks: {
		                    callback: function(label, index, labels) {
		                        return label+' K';
		                    }
		                }
			        }]
			    }
			}
		});

	</script>
	<script src="<?php echo e(asset('assets/atlantis/js/plugin/chart-circle/circles.min.js')); ?>"></script>
	<script>
		<?php
			$a = 1;
			$b = count($jumlah_t);
			$colors = [ 1 => '#F25961','#2BB930','#FF9E27','#609dff'];
		?>
		<?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php $__currentLoopData = $jumlah_t; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($e->jenis_transaksi == $t->jenis): ?>
				Circles.create({
					id:'circles-<?php echo e($t->jenis); ?>',
					radius:45,
					value:<?php echo e($t->jumlah); ?>,
					maxValue:100,
					width:10,
					text: <?php echo e($t->jumlah); ?>,
					colors:['#f1f1f1', '<?php echo e($colors[$b--]); ?>' ],
					duration:400,
					wrpClass:'circles-wrp',
					textClass:'circles-text',
					styleWrapper:true,
					styleText:true
				})
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</script>
	<script>	
		$(document).ready(function(){
		  $('.btn-pop').popover({ 
		    html : true,
		    content: function() {
		      return $('#popover_content_wrapper').html();
		    }
		  });
		});
	</script>
	<script src="<?php echo e(asset('assets/atlantis/js/plugin/datatables/datatables.min.js')); ?>"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.8.4/moment.min.js"></script>
	<script src="https://cdn.datatables.net/plug-ins/1.10.19/sorting/datetime-moment.js"></script>
	<script>
		$(document).ready(function() {
			$.fn.dataTable.moment( 'DD/MM/YYYY HH:mm' );
			$('.transaksi').DataTable({
				 aaSorting: [[0, 'desc']],
				 columnDefs: [{
				    target: 0,
				    type: 'datetime-moment'
				  }],
				 "pageLength": 25
			});
		})
	</script>
	<script>
	$(document).ready(function () {
	    $('#FilterBtn').click(function() {
	      checked = $("input[type=checkbox]:checked").length;

	      if(!checked) {
	        return false;
	      }

	    });
	});
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/master-d', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>