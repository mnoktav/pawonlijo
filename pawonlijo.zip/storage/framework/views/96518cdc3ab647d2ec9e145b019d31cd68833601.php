<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/kasir/sales.blade.php */ ?>
<?php $__env->startSection('css'); ?>
	<style>

		#basic-datatables th, #basic-datatables td{
			font-size: 0.8rem !important;
			padding: 0.5rem !important;
			height: 2.5rem;
		}

	</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="page-inner">
		<div class="card">
			<div class="card-body">
				<h4 style="text-transform: uppercase;"><b>TRANSAKSI PENJUALAN <?php echo e(session('login')['nama_booth']); ?></b></h4>
				<div class="separator-solid"></div>
				<div class="table-responsive">
					<table id="basic-datatables" class="display table table-striped" style="padding: 0px;">
						<thead class="bg-dark text-light">
							<tr>
								<th>Tanggal</th>
								<th>ID. Transaksi</th>
								<th class="d-none d-sm-table-cell">Jenis</th>
								<th class="d-none d-sm-table-cell">Kode</th>
								<th class="d-none d-sm-table-cell">Subtotal</th>
								<th class="d-none d-sm-table-cell">Potongan</th>
								<th class="d-none d-sm-table-cell">Total</th>
								<th class="d-none d-sm-table-cell">Status</th>
								<th width="8%">Detail</th>
							</tr>
						</thead>
						<tbody>
							<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td><?php echo e(date('d/m/Y H:i',strtotime($sale->created_at))); ?></td>
								<td><?php echo e($sale->id); ?></td>
								<td class="d-none d-sm-table-cell"><?php echo e($sale->jenis); ?></td>
								<?php if($sale->kode != null): ?>
								<td class="d-none d-sm-table-cell"><?php echo e($sale->kode); ?></td>
								<?php else: ?>
								<td class="d-none d-sm-table-cell">-</td>
								<?php endif; ?>
								<td class="d-none d-sm-table-cell">Rp <?php echo e(Rupiahd($sale->subtotal)); ?></td>
								<td class="d-none d-sm-table-cell">Rp <?php echo e(Rupiahd($sale->potongan)); ?></td>
								<td class="d-none d-sm-table-cell">Rp <?php echo e(Rupiahd($sale->total)); ?></td>
								<?php if($sale->status == 1): ?>
								<td class="d-none d-sm-table-cell">Sukses</td>
								<?php else: ?>
								<td class="d-none d-sm-table-cell">Batal</td>
								<?php endif; ?>
								<td>
									<a href="<?php echo e(route('kasir.transaksi-detail',$sale->id)); ?>" class="btn btn-primary btn-sm"><i class="fas fa-info"></i></a>
								</td>
							</tr>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</tbody>
					</table>		
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
	<script src="<?php echo e(asset('assets/atlantis/js/plugin/datatables/datatables.min.js')); ?>"></script>
	<script>
		$(document).ready(function() {
			$('#basic-datatables').DataTable({
				 aaSorting: [[0, 'desc']]
			});
		})
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('kasir/master-d', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>