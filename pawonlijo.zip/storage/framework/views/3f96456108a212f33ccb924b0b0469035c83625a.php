<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/kasir/product.blade.php */ ?>
<?php $__env->startSection('css'); ?>
	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="page-inner">
		<div class="row">
			<div class="col-md-12" id="produk">
				<div class="card border">
					<div class="card-body">
						<div class="row">
							<div class="col-md-6">
								<h4 style="text-transform: uppercase;"><b>PRODUK <?php echo e(session('login')['nama_booth']); ?></b></h4>
								<small style="text-transform: uppercase;">Order : <?php echo e($jenis); ?></small>

							</div>
							<div class="col-md-6 mt-2">
								<div class="text-right">
									<?php if(session('cart') == null): ?>
									<a class="btn btn-sm btn-rounded btn-primary mr-2" href="<?php echo e(route('kasir.dashboard')); ?>">
										<span class="btn-label">
											<i class="fas fa-angle-left"></i>
										</span>
										Kembali
									</a>
									<?php else: ?>
									<a class="btn btn-sm btn-rounded btn-primary mr-2 reset" href="<?php echo e(route('kasir.product-reset-back')); ?>">
										<span class="btn-label">
											<i class="fas fa-angle-left"></i>
										</span>
										Kembali
									</a>
									<?php endif; ?>
									<a class="btn btn-sm btn-rounded btn-success" href="<?php echo e(route('kasir.checkout',['jenis'=>$jenis, 'id'=>$id_jenis])); ?>">
										<b>Checkout</b>
										<?php if(session('cart') != null): ?>
											<span class="ml-2"><?php echo e(count(session('cart'))); ?> item</span>
										<?php endif; ?>
									</a>
								</div>
							</div>
						</div>
						<div class="separator-solid"></div>
						<div class="row">
							<div class="col-md-12">
								<div class="form-group" style="padding: 0; margin-bottom: 1rem;">
									<div class="input-icon">
										<input type="text" class="form-control" placeholder="Search for..." id="search" onkeyup="Search()" style="border: 1px #cccccc solid;">
										<span class="input-icon-addon">
											<i class="fa fa-search"></i>
										</span>
									</div>
								</div>
							</div>
							<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-md-4 target">
								<div class="card border">
									<form action="<?php echo e(route('kasir.product-add')); ?>" method="POST">
									<?php echo csrf_field(); ?>
									<input type="hidden" name="jenis" value="<?php echo e($jenis); ?>">
									<div class="card-body list-produk" style="background-color: #f4f4f4;">
										<div class="row">
											<div class="col-8">
												<div class="produk mb-3">
													<h5 style="text-transform: capitalize;"><b><i class="fas fa-tag text-danger mr-2"></i><?php echo e($product->nama_makanan); ?></b></h5>
													<p class="ml-3 pl-1">Rp <?php echo e(Rupiahd($product->harga)); ?></p>
													<input type="hidden" name="harga" value="<?php echo e($product->harga); ?>">
													
													<input type="hidden" name="id_product" value="<?php echo e($product->id_produk); ?>">
													<input type="hidden" name="id_jenis" value="<?php echo e($product->id_jenis_transaksi); ?>">
												</div>
											</div>
											<div class="col-4 <?php echo e($jenis == 'Pesanan' ? 'd-none':null); ?>">
												<p><b>Stok</b></p>
												<?php $__currentLoopData = $stok; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
													<?php if($s->id_produk == $product->id_produk): ?>
														<p class="mt--3"><?php echo e($s->sisa_stok); ?></p>
														<input type="hidden" name="sisa" value="<?php echo e($s->sisa_stok); ?>">
													<?php endif; ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</div>
											<div class="col-7">
												<div class="form-group p-0">	
												    <input type="number" class="form-control border mr-6 ml-6" id="jumlah" name="jumlah" placeholder="Jumlah" min="1">
												</div>
											</div>
											<div class="col-5 mt-1">
												<div class="button-submit text-center">
													<input type="submit" name="pesan" value="Pesan" class="btn btn-primary btn-sm">
												</div>
											</div>
										</div>
										
									</div>
									</form>
								</div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
	<script>
		function Search() {
		  var input = document.getElementById("search");
		  var filter = input.value.toLowerCase();
		  var nodes = document.getElementsByClassName('target');

		  for (i = 0; i < nodes.length; i++) {
		    if (nodes[i].innerText.toLowerCase().includes(filter)) {
		      nodes[i].style.display = "block";
		    } else {
		      nodes[i].style.display = "none";
		    }
		  }
		}
	</script>
	<script>
		$(document).ready(function(){
		    $('.reset').on('click', function(e){
		        e.preventDefault(); //cancel default action

		        //Recuperate href value
		        var href = $(this).attr('href');
		        var message = $(this).data('confirm');

		        //pop up
		        swal({
		            title: "Transaksi Belum Selesai",
		            text: "Item dihalaman checkout akan dihapus", 
		            icon: "warning",
		            buttons: true,
		            dangerMode: true,
		        })
		        .then((willDelete) => {
		          if (willDelete) {
		            window.location.href = href;
		          }
		        });
		    });
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('kasir/master-d', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>