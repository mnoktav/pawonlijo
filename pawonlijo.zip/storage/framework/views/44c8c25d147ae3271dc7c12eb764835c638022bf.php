<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/admin/product-booth.blade.php */ ?>
<?php $__env->startSection('booth-product'); ?>	
	<div class="row">
		<?php $__currentLoopData = $booths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<div class="col-md-3 target">
			<div class="card" style="border: 1px solid #dddddd">
				<div class="card-body">
					<div class="icon text-center">
						<i class="fas fa-store fa-3x text-danger"></i>
					</div>
					<div class="separator-solid"></div>
					<div class="nama-kota text-center">
						<h3 style="margin: 0; text-transform: capitalize;"><b><?php echo e($booth->nama_booth); ?></b></h3>
						<small style="text-transform: capitalize;"><?php echo e($booth->kota_booth); ?></small>
					</div>
					<div class="separator-solid"></div>
					<div class="lihat-menu text-center">
						<a href="<?php echo e(route('admin.product-booth-menu', $booth->id_booth)); ?>" class="btn btn-primary btn-sm btn-rounded" style="padding: 0.4rem 1rem;">Lihat Menu</a>
					</div>
				</div>
			</div>
		</div>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('admin/product', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>