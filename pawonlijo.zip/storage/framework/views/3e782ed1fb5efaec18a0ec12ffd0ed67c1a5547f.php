<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/auth/login.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="X-UA-Compatible" content="IE=edge" />
    <title>Admin Pawon Lijo</title>
    <meta content='width=device-width, initial-scale=1.0, shrink-to-fit=no' name='viewport' />
    <link rel="icon" href="../assets/img/icon.ico" type="image/x-icon"/>

    <!-- Fonts and icons -->
    <script src="<?php echo e(asset('assets/atlantis/js/plugin/webfont/webfont.min.js')); ?>"></script>
    <script>
        WebFont.load({
            google: {"families":["Lato:300,400,700,900"]},
            custom: {"families":["Flaticon", "Font Awesome 5 Solid", "Font Awesome 5 Regular", "Font Awesome 5 Brands", "simple-line-icons"], urls: ['<?php echo e(asset('assets/atlantis/css/fonts.min.css')); ?>']},
            active: function() {
                sessionStorage.fonts = true;
            }
        });
    </script>

    <!-- CSS Files -->
    <link rel="stylesheet" href="//code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
    <link rel="stylesheet" href="<?php echo e(asset('assets/atlantis/css/bootstrap.min.css')); ?> ">
    <link rel="stylesheet" href="<?php echo e(asset('assets/atlantis/css/atlantis.min.css')); ?> ">
    <?php echo $__env->yieldContent('css'); ?>
</head>
<body>
    <div class="container">
        <div class="row" style="position: relative; top: 120px;">
            <div class="col-md-4 mx-auto">
                <div class="card border">
                    <div class="card-body">
                        <div class="image text-center">
                            <img src="<?php echo e(asset('assets/img/usr.png')); ?>" class="img-fluid" alt="" width="20%">
                            <h3 class="mt-2"><b>LOGIN ADMIN</b></h3>
                        </div>
                        <div class="separator-solid"></div>
                        <form method="POST" action="<?php echo e(route('login')); ?>">
                            <?php echo csrf_field(); ?>
                            <div class="form-group">
                                <div class="input-icon <?php echo e($errors->has('username_booth') ? 'has-error' : null); ?>">
                                    <span class="input-icon-addon <?php echo e($errors->has('username_booth') ? 'text-danger' : null); ?>">
                                        <i class="fa fa-user"></i>
                                    </span>
                                    <input type="text" class="form-control" placeholder="Username" name="username" value="<?php echo e(old('username')); ?>" required autofocus>                                       
                                </div>
                                <?php if($errors->has('username')): ?>
                                    <span class="help-block text-danger mt-1">
                                        <?php echo e($errors->first('username')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>

                           
                            <div class="form-group">
                                <div class="input-icon <?php echo e($errors->has('password') ? 'has-error' : null); ?>">
                                    <span class="input-icon-addon <?php echo e($errors->has('password') ? 'text-danger' : null); ?>">
                                        <i class="fa fa-key"></i>
                                    </span>
                                    <input type="password" class="form-control" placeholder="Password" name="password" required>
                                </div>
                                <?php if($errors->has('password')): ?>
                                    <span class="help-block text-danger">
                                        <?php echo e($errors->first('password')); ?>

                                    </span>
                                <?php endif; ?>
                            </div>

                            <div class="text-center mt-3">
                                <button type="submit" class="btn btn-primary btn-rounded pl-5 pr-5">
                                    <?php echo e(__('Login')); ?>

                                </button>

                                <?php if(Route::has('password.request')): ?>
                                    <a class="btn btn-link" href="<?php echo e(route('password.request')); ?>">
                                        <?php echo e(__('Forgot Your Password?')); ?>

                                    </a>
                                <?php endif; ?>
                            </div>
                            <div class="button text-center mt-5 mb-0">
                                <small class="text-muted">2019, made by mno</small>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        
    </div>
    <!--   Core JS Files   -->
    <script src="<?php echo e(asset('assets/atlantis/js/core/jquery.3.2.1.min.js')); ?>"></script>
    <script src="https://code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
    <script src="<?php echo e(asset('assets/atlantis/js/core/popper.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/atlantis/js/core/bootstrap.min.js')); ?>"></script>

    <!-- jQuery UI -->
    <script src="<?php echo e(asset('assets/atlantis/js/plugin/jquery-ui-1.12.1.custom/jquery-ui.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/atlantis/js/plugin/jquery-ui-touch-punch/jquery.ui.touch-punch.min.js')); ?>"></script>

    <!-- jQuery Scrollbar -->
    <script src="<?php echo e(asset('assets/atlantis/js/plugin/jquery-scrollbar/jquery.scrollbar.min.js')); ?>"></script>

    <!-- Atlantis JS -->
    <script src="<?php echo e(asset('assets/atlantis/js/atlantis.min.js')); ?>"></script>
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
    <?php echo $__env->make('sweet::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html>