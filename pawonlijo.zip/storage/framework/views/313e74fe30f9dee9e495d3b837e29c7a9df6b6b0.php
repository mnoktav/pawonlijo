<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/admin/booth-add-step1.blade.php */ ?>
<?php $__env->startSection('step'); ?>	
	<div class="card" style="border: 1px solid #dddddd">
		<div class="card-body step">
			<h4><b>BOOOTH</b></h4>
			<div class="separator-dashed"></div>
			<form action="<?php echo e(route('admin.add-booth-save')); ?>" method="POST">
				<?php echo csrf_field(); ?>
				<div class="form-group <?php echo e($errors->has('id_booth') ? 'has-error' : null); ?>">
					<label for="id-booth">ID Booth</label>
					<small class="text-muted ml-2"><i>(Ex: JBG1)</i></small>
					<?php if(session('step1') != null): ?>
					<input type="text" class="form-control" id="id-booth" name="id_booth" value="<?php echo e(session('step1')['id_booth']); ?>" required="">
					<?php else: ?>
					<input type="text" class="form-control" id="id-booth" name="id_booth" value="<?php echo e(old('id_booth')); ?>" required="">
					<?php endif; ?>
					<?php if($errors->has('id_booth')): ?>
						<span class="help-block text-danger">
							<?php echo e($errors->first('id_booth')); ?>

						</span>
					<?php endif; ?>
				</div>
				<div class="form-group <?php echo e($errors->has('nama_booth') ? 'has-error' : null); ?>">
					<label for="nama-booth">Nama Booth</label>
					<?php if(session('step1') != null): ?>
					<input type="text" class="form-control" id="nama-booth" name="nama_booth" value="<?php echo e(session('step1')['nama_booth']); ?>" required="">
					<?php else: ?>
					<input type="text" class="form-control" id="nama-booth" name="nama_booth" value="<?php echo e(old('nama_booth')); ?>" required="">
					<?php endif; ?>
					<?php if($errors->has('nama_booth')): ?>
						<span class="help-block text-danger">
							<?php echo e($errors->first('nama_booth')); ?>

						</span>
					<?php endif; ?>
				</div>
				<div class="form-group">
					<label for="alamat-booth">Alamat Booth</label>
					<?php if(session('step1') != null): ?>
					<textarea class="form-control" id="alamat-booth" name="alamat_booth"><?php echo e(session('step1')['alamat_booth']); ?></textarea>
					<?php else: ?>
					<textarea class="form-control" id="alamat-booth" name="alamat_booth"><?php echo e(old('alamat_booth')); ?></textarea>
					<?php endif; ?>
				</div>
				<div class="form-group">
					<label for="kota">Kota</label>
					<?php if(session('step1') != null): ?>
					<input type="text" class="form-control" id="kota" name="kota" value="<?php echo e(session('step1')['kota']); ?>" required="">
					<?php else: ?>
					<input type="text" class="form-control" id="kota" name="kota" value="<?php echo e(old('kota')); ?>" required="">
					<?php endif; ?>
				</div>
				<div class="row">
					<div class="col-md-6">
						<div class="form-group">
							<label for="jam-buka">Jam Buka</label>
							<?php if(session('step1') != null): ?>
							<input type="time" class="form-control" id="jam-buka" name="jam_buka" value="<?php echo e(session('step1')['jam_buka']); ?>" required="">
							<?php else: ?>
							<input type="time" class="form-control" id="jam-buka" name="jam_buka" value="<?php echo e(old('jam_buka')); ?>" required="">
							<?php endif; ?>
						</div>
					</div>
					<div class="col-md-6">
						<div class="form-group">
							<label for="jam-tutup">Jam Tutup</label>
							<?php if(session('step1') != null): ?>
							<input type="time" class="form-control" id="jam-tutup" name="jam_tutup" value="<?php echo e(session('step1')['jam_tutup']); ?>" required="">
							<?php else: ?>
							<input type="time" class="form-control" id="jam-tutup" name="jam_tutup" value="<?php echo e(old('jam_tutup')); ?>" required="">
							<?php endif; ?>
						</div>
					</div>
				</div>
				<div class="form-group">
					<label for="nomor">Nomor Telephone</label>
					<?php if(session('step1') != null): ?>
					<input type="text" class="form-control" id="nomor" name="nomor" value="<?php echo e(session('step1')['nomor']); ?>" onkeypress="return NumberOnly()">
					<?php else: ?>
					<input type="text" class="form-control" id="nomor" name="nomor" value="<?php echo e(old('nomor')); ?>" onkeypress="return NumberOnly(event)">
					<?php endif; ?>
				</div>
				<div class="text-center" style="margin: 1rem 0;">
					<input type="submit" name="step1" value="Next" class="btn btn-success btn-rounded">
				</div>
			</form>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/booth-add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>