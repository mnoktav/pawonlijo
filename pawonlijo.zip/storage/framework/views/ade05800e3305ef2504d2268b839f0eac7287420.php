<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/admin/product-stock.blade.php */ ?>
<?php $__env->startSection('content'); ?>	
	<div class="page-inner">
		<div class="page-header">
			<h4 class="page-title">Stok Menu PawonLijo</h4>
			<ul class="breadcrumbs">
				<li class="nav-home">
					<a href="<?php echo e(route('admin.dashboard')); ?>">
						<i class="flaticon-home"></i>
					</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a>Stok Menu PawonLijo</a>
				</li>
			</ul>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-body">
						<div class="row">
							<div class="col-md-12 mb-1">
								<div class="form-group" style="padding: 0;">
									<div class="input-icon">
										<input type="text" class="form-control" placeholder="Search for..." id="search" onkeyup="Search()" style="border: 1px #cccccc solid;">
										<span class="input-icon-addon">
											<i class="fa fa-search"></i>
										</span>
									</div>
								</div>
								<div class="separator-solid"></div>
							</div>
							<?php $__currentLoopData = $booths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-md-3 target">
								<div class="card" style="border: 1px solid #dddddd">
									<div class="card-body">
										<div class="icon text-center">
											<i class="fas fa-store fa-3x text-danger"></i>
										</div>
										<div class="separator-solid"></div>
										<div class="nama-kota text-center">
											<h3 style="margin: 0;"><b><?php echo e($booth->nama_booth); ?></b></h3>
											<small><?php echo e($booth->kota_booth); ?></small>
										</div>
										<div class="separator-solid"></div>
										<div class="lihat-menu text-center">
											<a href="<?php echo e(route('admin.stock-product-booth', $booth->id_booth)); ?>" class="btn btn-primary btn-sm btn-rounded" style="padding: 0.4rem 1rem;">Lihat Stok Menu</a>
										</div>
									</div>
								</div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/master-d', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>