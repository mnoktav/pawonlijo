<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/admin/report-excel.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	
</head>
<body style="margin: 0;">
	
	<table class="table table-bordered transaksi border" width="100%">
		<thead>
			<tr>
				<th>TANGGAL</th>
				<th>ID TRANSAKSI</th>
				<th>JENIS</th>
				<th>KODE</th>
				<th>SUBTOTAL</th>
				<th>PAJAK</th>
				<th>DISCOUNT</th>
				<th>TOTAL</th>
			</tr>
		</thead>
		<tbody>
			<?php
				$total_b = 0;
			?>
			<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				
				<tr style="background-color: #e0e0e0">
					<td><?php echo e(date('d/m/Y H:i',strtotime($sale->created_at))); ?></td>
					<td><?php echo e($sale->id); ?></td>
					<td><?php echo e($sale->jenis); ?></td>
					<?php if($sale->kode != null): ?>
					<td><?php echo e($sale->kode); ?></td>
					<?php else: ?>
					<td>-</td>
					<?php endif; ?>
					<td><?php echo e($sale->subtotal); ?></td>
					<td><?php echo e($sale->total_pajak); ?></td>
					<td><?php echo e($sale->potongan); ?></td>
					<td><?php echo e($sale->total_bersih); ?></td>
				</tr>
				<tr style="background-color: #f9f9f9;">
					<td>Detail : </td>
					<td>Nama Makanan </td>
					<td>Harga</td>
					<td>Jumlah</td>
				</tr>
				<?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($sale->id == $d->id_transaksi): ?>
					<tr style="background-color: #f9f9f9;">
						<td></td>
						<td><?php echo e($d->nama_makanan); ?></td>
						<td><?php echo e($d->harga_satuan); ?></td>
						<td><?php echo e($d->jumlah); ?></td>
					</tr>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php
				
					$total_b += $sale->total_bersih;
				?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</tbody>
	</table>
	
</body>
</html>


