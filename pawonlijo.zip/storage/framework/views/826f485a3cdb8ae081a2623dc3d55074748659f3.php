<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/kasir/report.blade.php */ ?>
<?php $__env->startSection('css'); ?>
	<style>
		.table td, .table th{
			padding: 0.5rem !important;
		}
	</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
	<div class="page-inner">
		<div class="card">
			<div class="card-body">
				<div class="row">
					<div class="col-md-8">
						<h4 style="text-transform: uppercase;"><b>REPORT HARIAN <?php echo e(session('login')['nama_booth']); ?></b></h4>
					</div>
					<div class="col-md-4 text-right">
						<small class="ml-4">Update terakhir : 20:11 WIB</small>
					</div>
				</div>
				<div class="separator-solid mb-4"></div>
				<div class="row ">
					<div class="col-sm-6 col-md-4">
						<div class="card card-stats card-round border">
							<div class="card-body">
								<div class="row align-items-center">
									<div class="col-icon">
										<div class="icon-big text-center icon-success bubble-shadow-small">
											<i class="flaticon-graph"></i>
										</div>
									</div>
									<div class="col col-stats ml-3 ml-sm-0">
										<div class="numbers">
											<p class="card-category">Pemasukan</p>
											<h4 class="card-title">Rp <?php echo e($total/1000); ?> K</h4>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-6 col-md-4">
						<div class="card card-stats card-round border">
							<div class="card-body">
								<div class="row align-items-center">
									<div class="col-icon">
										<div class="icon-big text-center icon-primary bubble-shadow-small">
											<i class="flaticon-success"></i>
										</div>
									</div>
									<div class="col col-stats ml-3 ml-sm-0">
										<div class="numbers">
											<p class="card-category">Transaksi Berhasil</p>
											<h4 class="card-title"><?php echo e($ts); ?> Transaksi</h4>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
					<div class="col-sm-6 col-md-4">
						<div class="card card-stats card-round border">
							<div class="card-body">
								<div class="row align-items-center">
									<div class="col-icon">
										<div class="icon-big text-center icon-danger bubble-shadow-small">
											<i class="flaticon-error"></i>
										</div>
									</div>
									<div class="col col-stats ml-3 ml-sm-0">
										<div class="numbers">
											<p class="card-category">Transaksi Batal</p>
											<h4 class="card-title"><?php echo e($tb); ?> Transaksi</h4>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
				<div class="card">
					<div class="card-body border">
						<div class="row">
							<div class="col-md-6">
								<div class="table-responsive">
									<table class="table table-striped">
										<tr>
											<th width="20%" colspan="3">Produk Terjual</th>
										</tr>
										<?php
											$i = 1;
										?>
										<?php if(count($jh) == null): ?>
											<tr class="text-center">
												<td colspan="3">Belum Ada Produk terjual</td>
											</tr>
										<?php else: ?>
											<?php $__currentLoopData = $jh; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<tr>
													<td width="5%"><?php echo e($i++); ?>.</td>
													<td width="30%"><?php echo e($jh->nama_makanan); ?></td>
													<td><?php echo e($jh->jumlah); ?> Porsi</td>
												</tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										<?php endif; ?>
									</table>
								</div>
							</div>
							<div class="col-md-6">
								<div class="card full-height shadow-none">
									<div class="card-body">
										<div class="d-flex flex-wrap justify-content-around pb-2 pt-4">
											<?php $__currentLoopData = $jt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<div class="px-2 pb-2 pb-md-0 text-center">
													<div id="circles-<?php echo e($j->jenis); ?>"></div>
													<h6 class="fw-bold mt-3 mb-0"><?php echo e($j->jenis); ?></h6>
												</div>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
	<script src="<?php echo e(asset('assets/atlantis/js/plugin/chart-circle/circles.min.js')); ?>"></script>
	<script>
		<?php
			$a = 1;
			$b = count($jt);
			$colors = [ 1 => '#F25961','#2BB930','#FF9E27','#609dff'];
		?>
		<?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<?php $__currentLoopData = $jt; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($e->jenis_transaksi == $t->jenis): ?>
				Circles.create({
					id:'circles-<?php echo e($t->jenis); ?>',
					radius:45,
					value:<?php echo e($t->jumlah); ?>,
					maxValue:30,
					width:10,
					text: <?php echo e($t->jumlah); ?>,
					colors:['#f1f1f1', '<?php echo e($colors[$b--]); ?>' ],
					duration:400,
					wrpClass:'circles-wrp',
					textClass:'circles-text',
					styleWrapper:true,
					styleText:true
				})
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('kasir/master-d', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>