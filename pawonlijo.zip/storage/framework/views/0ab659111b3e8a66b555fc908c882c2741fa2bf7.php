<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/admin/booth-detail-transaksi.blade.php */ ?>
<?php $__env->startSection('css'); ?>
	<style>
		#basic-datatables th, #basic-datatables td{
			padding: 0.5rem !important;
			font-size: 0.8rem;
			height: 2.5rem;
		}
	</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content2'); ?>	
	
	<div class="card" style="border: 1px solid #dddddd;">
		<div class="card-body">
			<h4><b><span class="fas fa-list-ol text-warning"></span>&nbsp; Transaksi</b></h4>
			<div class="separator-solid"></div>
			<div class="table-responsive">
				<table id="basic-datatables" class="display table table-striped table-hover" style="padding: 0px;">
					<thead class="bg-dark text-light">
						<tr style="text-transform: uppercase;">
							<th>Tanggal</th>
							<th>ID. Transaksi</th>
							<th>Jenis (Pajak)</th>
							<th>Kode</th>
							<th>Total</th>
							<th>Discount</th>
							<th>Pajak</th>
							<th>Total Bersih</th>
							<th>Status</th>
							<th>Detail</th>
						</tr>
					</thead>
					<tbody>
						<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr>
							<td><?php echo e(date('d/m/Y H:i', strtotime($sale->created_at))); ?></td>
							<td><?php echo e($sale->id); ?></td>
							<td><?php echo e($sale->jenis); ?> (<?php echo e($sale->pajak); ?>%)</td>
							<td><?php echo e($sale->kode); ?></td>
							<td>Rp <?php echo e(Rupiahd($sale->subtotal)); ?></td>
							<td>Rp <?php echo e(Rupiahd($sale->potongan)); ?></td>
							<td>Rp <?php echo e(Rupiahd($sale->total_pajak)); ?></td>
							
							<td>Rp <?php echo e(Rupiahd($sale->total_bersih)); ?></td>
							<?php if($sale->status == 2): ?>
							<td class="d-none d-sm-table-cell">Pending</td>
							<?php elseif($sale->status == 1 and $sale->jenis == 'Pesanan'): ?>
							<td class="d-none d-sm-table-cell">
								Selesai <br><small><?php echo e(date('d/m/Y H:i', strtotime($sale->updated_at))); ?></small>
							</td>
							<?php elseif($sale->status == 1 and $sale->jenis != 'Pesanan'): ?>
							<td class="d-none d-sm-table-cell">Sukses</td>
							<?php else: ?>
							<td class="d-none d-sm-table-cell">Batal</td>
							<?php endif; ?>
							<td><a href="<?php echo e(route('admin.sales-detail',$sale->id)); ?>" class="btn btn-primary btn-sm btn-rounded">Detail</a></td>
						</tr>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					</tbody>
				</table>		
			</div>
		</div>
	</div>
	
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/booth-detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>