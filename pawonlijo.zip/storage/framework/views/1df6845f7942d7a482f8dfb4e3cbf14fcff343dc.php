<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/admin/booth-add-step5.blade.php */ ?>
<?php $__env->startSection('css'); ?>
	<style>
		.table td, .table th{
			height: 2.5rem;
			border: none;
		}
		.form-control{
			height: 2rem !important;
			border: 1px solid #aaaaaa;
		}
	</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('step'); ?>
	<div class="card" style="border: 1px solid #dddddd">
		<div class="card-body step">
			<div class="row">
				<div class="col-md-12" style="padding: 1rem;">
					<h3><i class="fas fa-check text-warning"></i> &nbsp; <b>BERHASIL</b></h3>
					<div class="separator-solid" style="border-color: #dddddd"></div>
					<div class="alert alert-info bg-info text-light" role="alert">
					  <i class="fas fa-check-circle"></i> &nbsp;<b>BOOTH BARU BERHASIL DIBUAT!</b>
					</div>
				</div>
				<form action="<?php echo e(route('admin.add-booth-save')); ?>" method="POST">
					<?php echo csrf_field(); ?>
					<div class="col-md-12" id="daftar-menu">
						<div class="card border shadow-none">
							<div class="card-body" style="height: 300px; overflow-y: scroll;">
								<h5><b>DAFTAR MENU</b></h5>
								<div class="separator-solid"></div>
								<table class="table table-borderless">
									<tr>
										<th><input type="checkbox" class="mr-1" id="select-all"></th>
										<th>Nama</th>
										<?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										
										<th><?php echo e($e->jenis_transaksi); ?></th>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
										
									</tr>
									<input type="hidden" name="id_booth" value="<?php echo e($booth); ?>">
									<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
									<tr>
										<td width="5%"><input type="checkbox" class="checkitem" name="nama_makanan[]" value="<?php echo e($p->nama_makanan); ?>"></td>
										<td width="15%"><?php echo e($p->nama_makanan); ?> <input type="hidden" name="kategori[]" value="<?php echo e($p->kategori); ?>"></td>
										<?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $je): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<td><input type="text" class="form-control" name="harga[]" value="" onkeypress="return NumberOnly()"></td>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tr>
									<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
								</table>
								
							</div>
						</div>
					</div>
					<div class="col-md-12">
						<div class="text-center">
							<input type="submit" name="selesai" value="Selesai" class="btn btn-primary btn-sm">
						</div>
					</div>
				</form>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
	<script>
		$(document).ready(function() {
	        $('#select-all').click(function(event) {  
	            if(this.checked) { 
	                $('.checkitem').each(function() { 
	                    this.checked = true;     
	                });
	            }else{
	                $('.checkitem').each(function() {
	                    this.checked = false; 
	                });        
	            }
	        });

	    });
	</script>
	<script>
		window.location.hash="no-back-button";
		window.location.hash="Again-No-back-button";//again because google chrome don't insert first hash into history
		window.onhashchange=function(){window.location.hash="no-back-button";}
	</script> 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/booth-add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>