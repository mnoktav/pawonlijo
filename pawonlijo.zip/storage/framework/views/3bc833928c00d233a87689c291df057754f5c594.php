<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/admin/booth-jenis-transaksi.blade.php */ ?>
<?php $__env->startSection('css'); ?>
	<style>
		.table th, .table td{
			height: 2.5rem !important;
			padding: 0.5rem !important;
		}
	</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>	
	<div class="page-inner">
		<div class="page-header">
			<h4 class="page-title">Jenis Transaksi Booth PawonLijo</h4>
			<ul class="breadcrumbs">
				<li class="nav-home">
					<a href="<?php echo e(route('admin.dashboard')); ?>">
						<i class="flaticon-home"></i>
					</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a>Pajak</a>
				</li>
			</ul>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-body">
						<div class="row">
							<?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-md-3">
								<div class="card card-pricing border">
									<div class="card-header">
										<h4 class="card-title"><?php echo e($j->jenis_transaksi); ?></h4>
										<div class="card-price">
											<span class="price"><?php echo e($j->pajak); ?>%</span><br>
											<span>Pajak</span>
										</div>
									</div>
									<div class="card-footer">
										<button class="btn btn-block btn-primary open-edit" data-target=".bd-example-modal-sm" data-toggle="modal" data-id="<?php echo e($j->id); ?>" data-pajak="<?php echo e($j->pajak); ?>" data-nama="<?php echo e($j->jenis_transaksi); ?>"><b>Edit Pajak</b></button>
									</div>
								</div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
						<div class="separator-solid mt--2"></div>
						<div class="row mt-2">
							
							<div class="col-md-12">
								<table class="table table-striped pajak">
									<thead class="bg-warning text-light">
										<tr>
											<th>Tanggal</th>
											<th>Nama Booth</th>
											<th>Jenis Transaksi</th>
											<th>Pajak</th>
											<th>Detail</th>
										</tr>
									</thead>
									<tbody>
										<?php $__currentLoopData = $tax; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
										<tr>
											<td><?php echo e(date('d/m/Y', strtotime($t->tanggal))); ?></td>
											<?php $__currentLoopData = $booths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $b): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($b->id_booth == $t->id_booth): ?>
													<td><?php echo e($b->nama_booth.', '.$b->kota_booth); ?> (<?php echo e($t->id_booth); ?>)</td>
												<?php endif; ?>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<td><?php echo e($t->jenis); ?></td>
											<td>Rp <?php echo e(Rupiahd($t->pajak)); ?></td>
											<td><a href="/admin/tax/<?php echo e(date('Y-m-d', strtotime($t->tanggal))); ?>/<?php echo e($t->id_booth); ?>/<?php echo e($t->jenis); ?>" class="btn btn-primary btn-sm btn-rounded">Detail</a></td>
										</tr>
										<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
									</tbody>
								</table>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="modal fade bd-example-modal-sm mt-4" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
	  	<div class="modal-dialog modal-sm">
	    	<div class="modal-content">
	    		<form action="<?php echo e(route('admin.pajak-booth-transaksi')); ?>" method="POST">
	    			<?php echo csrf_field(); ?>
		      		<div class="modal-header">
				        <h5 class="modal-title">Edit Transaksi</h5>
				        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
				          <span aria-hidden="true">&times;</span>
				        </button>
				    </div>
				    <div class="modal-body">
				        <div class="form-group">
				        	<label for="">Nama Transaksi</label>
				        	<input type="text" class="form-control" id="nama_transaksi" name="jenis_transaksi" value="" readonly>
				        </div>
				        <div class="form-group">
				        	<label for="">Pajak</label>
				        	<input type="number" min="0" class="form-control" name="pajak" id="pajak" value="">
				        </div>
				    </div>
				    <div class="modal-footer">
				        <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
				        <input type="submit" class="btn btn-primary btn-sm" name="batal" value="Update">
				    </div>
			    </form>
	    	</div>
	  	</div>
	</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
	<script>
		$(document).on("click", ".open-edit", function (e) {
			var id = $(this).data('id');
			var nama_transaksi = $(this).data('nama');
			var pajak = $(this).data('pajak');

     		$(".modal-body #id_jenis").val(id);
     		$(".modal-body #nama_transaksi").val(nama_transaksi);
     		$(".modal-body #pajak").val(pajak);
		});
	</script>
	<script src="<?php echo e(asset('assets/atlantis/js/plugin/datatables/datatables.min.js')); ?>"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.8.4/moment.min.js"></script>
	<script src="https://cdn.datatables.net/plug-ins/1.10.19/sorting/datetime-moment.js"></script>
	<script>
		$(document).ready(function() {
			$.fn.dataTable.moment( 'DD/MM/YYYY' );
			$('.pajak').DataTable({
				 aaSorting: [[0, 'desc']],
				 columnDefs: [{
				    target: 0,
				    type: 'datetime-moment'
				  }],
				 "pageLength": 25
			});
		})
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/master-d', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>