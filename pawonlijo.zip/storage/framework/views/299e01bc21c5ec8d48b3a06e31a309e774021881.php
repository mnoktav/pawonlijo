<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/admin/report.blade.php */ ?>
<?php $__env->startSection('css'); ?>
	<style>
		.card input, .card select{
			border: 1px solid #dddddd;
		}
		.table th, .table td{
			padding: 0.7rem !important;
			font-size: 0.8rem;
			height: 1rem !important;
		}
	</style>
	
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>	
	<div class="page-inner">
		<div class="page-header">
			<h4 class="page-title">Laporan Penjualan</h4>
			<ul class="breadcrumbs">
				<li class="nav-home">
					<a href="<?php echo e(route('admin.dashboard')); ?>">
						<i class="flaticon-home"></i>
					</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a>Laporan Penjualan</a>
				</li>
			</ul>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-body">
						<div class="row">
							<div class="col-md-3">
								<div class="card border shadow-sm">
									<div class="card-body">
										<h4><b>CETAK LAPORAN</b></h4>
										<div class="separator-solid"></div>
										<form action="" method="GET">
											<div class="form-group p-0 mb-1">
												<label for="nama-booth" class="col-form-label">Booth : </label>
												<select class="form-control" name="id_booth" id="nama-booth">
													<option value="">Semua</option>
													<?php $__currentLoopData = $booths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
														<option value="<?php echo e($booth->id_booth); ?>" <?php echo e($id_booth == $booth->id_booth ? 'selected' : null); ?>><?php echo e($booth->nama_booth); ?>, <?php echo e($booth->kota_booth); ?></option>
													<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
												</select>
											</div>
											<div class="form-group p-0 mb-1">
												<label class="col-form-label">Tanggal Awal</label>
												<input type="date" class="form-control" required="" name="awal" value="<?php echo e($awal); ?>">
											</div>
											<div class="form-group p-0 mb-1">
												<label class="col-form-label">Tanggal Akhir</label>
												<input type="date" class="form-control" name="akhir" value="<?php echo e($akhir); ?>">
											</div>
											<input type="submit" class="btn btn-primary btn-sm btn-block mt-3" value="Cari" name="cari">
											<p class="text-danger mt-3">* Catatan : untuk mencari data harian cukup isi tanggal awal saja</p>
										</form>
									</div>
								</div>
							</div>
							<div class="col-md-9">
								<div class="card shadow-none" id="tabel-penjualan">
									<div class="card-body">
										<?php if(is_null($sales)): ?>
											<div class="text-center text-muted border mt--3">
												<h4 style="text-transform: uppercase; padding: 28% 0"><b>Isi Terlebih Dahulu Form Disamping ...</b></h4>
											</div>
										<?php elseif(count($sales) == null): ?>
											<div class="text-center text-muted">
												<h4><b>Tidak Ada Transaksi</b></h4>
											</div>
										<?php else: ?>
										
										<div>
											<a class="btn btn-default btn-sm pr-3 pl-3 mr-2" href="/admin/report/excel?awal=<?php echo e($awal); ?>&akhir=<?php echo e($akhir); ?>&id_booth=<?php echo e($id_booth); ?>" target="_blank"><i class="fas fa-file-excel mr-2"></i>Export to Excel</a>
										</div>
							
										<div class="print-content">
											
											<div class="separator-solid"></div>
											
											<iframe src="/admin/report/pdf?awal=<?php echo e($awal); ?>&akhir=<?php echo e($akhir); ?>&id_booth=<?php echo e($id_booth); ?>" style="height: 600px; width:100%">
											</iframe>

											<?php endif; ?>
											

										</div>
									</div>
								</div>
							</div>
						</div>
						
						
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
	
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/master-d', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>