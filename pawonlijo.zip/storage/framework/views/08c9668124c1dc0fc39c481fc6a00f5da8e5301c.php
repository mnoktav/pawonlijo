<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/admin/booth-add-step2.blade.php */ ?>
<?php $__env->startSection('step'); ?>	
	<div class="card" style="border: 1px solid #dddddd">
		<div class="card-body step">
			<form action="<?php echo e(route('admin.add-booth-save')); ?>" method="POST">
				<?php echo csrf_field(); ?>
				<div class="form-group <?php echo e($errors->has('username_booth') ? 'has-error' : null); ?>">					
					<label for="username_booth">Username</label>
					<?php if(session('step2') != null): ?>
					<input type="text" class="form-control" id="username_booth" name="username_booth" value="<?php echo e(session('step2')['username_booth']); ?>">
					<?php else: ?>
					<input type="text" class="form-control" id="username_booth" name="username_booth" value="<?php echo e(old('username_booth')); ?>">
					<?php endif; ?>
					<?php if($errors->has('username_booth')): ?>
						<span class="help-block text-danger">
							<?php echo e($errors->first('username_booth')); ?>

						</span>
					<?php endif; ?>
				</div>
				<div class="form-group <?php echo e($errors->has('password_booth') ? 'has-error' : null); ?>" >
					<label for="password_booth">Password</label>
					<?php if(session('step2') != null): ?>
					<input type="password" class="form-control" id="password_booth" name="password_booth" value="<?php echo e(session('step2')['password_booth']); ?>">
					<?php else: ?>
					<input type="password" class="form-control" id="password_booth" name="password_booth" value="<?php echo e(old('password_booth')); ?>">
					<?php endif; ?>
					<?php if($errors->has('password_booth')): ?>
						<span class="help-block text-danger">
							<?php echo e($errors->first('password_booth')); ?>

						</span>
					<?php endif; ?>
				</div>
				<div class="form-group <?php echo e($errors->has('re_pass') ? 'has-error' : null); ?>">
					<label for="re_pass">Ketik Ulang Password</label>
					<?php if(session('step2') != null): ?>
					<input type="password" class="form-control" id="re_pass" name="re_pass" value="<?php echo e(session('step2')['re_pass']); ?>">
					<?php else: ?>
					<input type="password" class="form-control" id="re_pass" name="re_pass" value="<?php echo e(old('re_pass')); ?>">
					<?php endif; ?>
					<?php if($errors->has('re_pass')): ?>
						<span class="help-block text-danger">
							<?php echo e($errors->first('re_pass')); ?>

						</span>
					<?php endif; ?>
				</div>
				<div class="text-center" style="margin: 1rem 0;">
					<a href="<?php echo e(route('admin.add-booth')); ?>" class="btn btn-warning btn-rounded">Back</a>
					<input type="submit" name="step2" value="Next" class="btn btn-success btn-rounded">
				</div>
			</form>
		</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/booth-add', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>