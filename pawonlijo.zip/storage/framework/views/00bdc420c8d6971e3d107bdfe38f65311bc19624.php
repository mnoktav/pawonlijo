<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/admin/booth-jenis-transaksi-pajak.blade.php */ ?>
<?php $__env->startSection('css'); ?>
	<style>
		.table th, .table td{
			height: 2.5rem !important;
			padding: 0.5rem !important;
		}
	</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>	
	<div class="page-inner">
		<div class="page-header">
			<h4 class="page-title">Detail Pajak Harian</h4>
			<ul class="breadcrumbs">
				<li class="nav-home">
					<a href="<?php echo e(route('admin.dashboard')); ?>">
						<i class="flaticon-home"></i>
					</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a>Pajak</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a>Detail</a>
				</li>
			</ul>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-body">
						<table class="table table-striped">
							<thead class="bg-warning text-light">
								<tr>
									<th>Tanggal</th>
									<th>ID Transaksi</th>
									<th>Jenis Transaksi</th>
									<th>Kode</th>
									<th>Pajak</th>
								</tr>
							</thead>
							<tbody>
								<?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
								<tr>
									<td><?php echo e(date('d/m/Y H:i',strtotime($d->created_at))); ?></td>
									<td><a href="<?php echo e(route('admin.sales-tax',$d->id)); ?>"><?php echo e($d->id); ?></a></td>
									<td><?php echo e($d->jenis); ?></td>
									<td><?php echo e($d->kode); ?></td>
									<td>Rp <?php echo e(Rupiah($d->total_pajak)); ?></td>
								</tr>
								<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							</tbody>
						</table>
					</div>
				</div>
			</div>
		</div>
	</div>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
	<script src="<?php echo e(asset('assets/atlantis/js/plugin/datatables/datatables.min.js')); ?>"></script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.8.4/moment.min.js"></script>
	<script src="https://cdn.datatables.net/plug-ins/1.10.19/sorting/datetime-moment.js"></script>
	<script>
		$(document).ready(function() {
			$.fn.dataTable.moment( 'DD/MM/YYYY' );
			$('.pajak').DataTable({
				 aaSorting: [[0, 'desc']],
				 columnDefs: [{
				    target: 0,
				    type: 'datetime-moment'
				  }],
				 "pageLength": 25
			});
		})
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/master-d', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>