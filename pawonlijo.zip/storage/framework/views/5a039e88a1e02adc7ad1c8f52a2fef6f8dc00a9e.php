<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/admin/report-pdf.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<style>
		.table{
			border-collapse: collapse;
		}
		.table th, .table td{
				padding: 0.5rem;
				font-size: 0.9rem;
				height: 1rem !important;
				border: 1px solid black;
				font-family: Arial, sans-serif;
			}
		.ringkasan th, .ringkasan td{
			font-size: 1rem;
		}
		.transaksi th{
			color: white;
		}
		.page-break {
		    page-break-after: always;
		}
		h3{
			margin-bottom: 0px;
			font-family: Arial,sans-serif;
		}
		h4{
			margin-top: 1%;
			font-family: Arial,sans-serif;
		}
	</style>
</head>
<body style="margin: 0;">
	<?php if($id_booth == null): ?>
		<div class="col-md-11 mt--1">
			<h3><b>LAPORAN PENJUALAN SEMUA BOOTH PAWON LIJO</b></h3>
			<?php if($akhir == '' || $akhir==$awal): ?>
				<h4>TANGGAL : <?php echo e(date('d/m/Y', strtotime($awal))); ?></h4>
				
			<?php else: ?>
				<h4>TANGGAL : <?php echo e(date('d/m/Y', strtotime($awal))); ?> - <?php echo e(date('d/m/Y', strtotime($akhir))); ?></h4>
			<?php endif; ?>
			
		</div>
	<?php else: ?>
		<div class="col-md-11 mt--1">
			<h3 style="text-transform: uppercase;"><b>LAPORAN PENJUALAN <?php echo e($nb->nama_booth); ?>, <?php echo e($nb->kota_booth); ?> (#<?php echo e($id_booth); ?>)</b></h3>
			<?php if($akhir == '' || $akhir==$awal): ?>
				<h4>TANGGAL : <?php echo e(date('d/m/Y', strtotime($awal))); ?></h4>
				
			<?php else: ?>
				<h4>TANGGAL : <?php echo e(date('d/m/Y', strtotime($awal))); ?> - <?php echo e(date('d/m/Y', strtotime($akhir))); ?></h4>
			<?php endif; ?>
		</div>
	<?php endif; ?>
	<table class="table table-bordered transaksi border" width="100%">
		<thead>
			<tr style="background-color: orange;">
				<th>TANGGAL</th>
				<th>ID TRANSAKSI</th>
				<th>JENIS</th>
				<th>KODE</th>
				<th>SUBTOTAL</th>
				<th>PAJAK</th>
				<th>DISCOUNT</th>
				<th>TOTAL</th>
			</tr>
		</thead>
		<tbody>
			<?php
				$total_b = 0;
			?>
			<?php $__currentLoopData = $sales; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sale): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				
				<tr style="background-color: #e0e0e0">
					<td><?php echo e(date('d/m/Y H:i',strtotime($sale->created_at))); ?></td>
					<td><?php echo e($sale->id); ?></td>
					<td><?php echo e($sale->jenis); ?></td>
					<?php if($sale->kode != null): ?>
					<td><?php echo e($sale->kode); ?></td>
					<?php else: ?>
					<td>-</td>
					<?php endif; ?>
					<td>Rp <?php echo e(Rupiahd($sale->subtotal)); ?></td>
					<td>Rp <?php echo e(Rupiahd($sale->total_pajak)); ?></td>
					<td>Rp <?php echo e(Rupiahd($sale->potongan)); ?></td>
					<td>Rp <?php echo e(Rupiahd($sale->total_bersih)); ?></td>
				</tr>
				<tr style="background-color: #f9f9f9;">
					<td>Detail : </td>
					<td>Nama Makanan </td>
					<td>Harga</td>
					<td>Jumlah</td>
					<td colspan="4"></td>
				</tr>
				<?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php if($sale->id == $d->id_transaksi): ?>
					<tr style="background-color: #f9f9f9;">
						<td></td>
						<td><?php echo e($d->nama_makanan); ?></td>
						<td>Rp <?php echo e(Rupiahd($d->harga_satuan)); ?></td>
						<td><?php echo e($d->jumlah); ?></td>
						<td colspan="4"></td>
					</tr>
					<?php endif; ?>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php
				
					$total_b += $sale->total_bersih;
				?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</tbody>
	</table>

	<h4 style="margin-top: 4%; text-transform: uppercase;">Ringkasan</h4>

	<table class="table table-bordered border ringkasan" width="100%" style="margin-bottom: 2%">
		<tr style="background-color: orange">
			<th colspan="2" style="text-transform: uppercase; color: white;">Produk Terjual</th>
		</tr>
		<tr>
			<th>Nama Produk</th>
			<th>Jumlah</th>
		</tr>
		<?php $__currentLoopData = $pj; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($p->nama_makanan); ?></td>
			<td><?php echo e($p->jumlah); ?> Porsi</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>

	<table class="table table-bordered border ringkasan" width="100%">
		<tr style="background-color: orange">
			<th colspan="4" style="text-transform: uppercase; color: white;">total Pendapatan & pajak</th>
		</tr>
		<tr>
			<th>Jenis</th>
			<th>Transaksi</th>
			<th>Pajak</th>
			<th>Total Bersih</th>
		</tr>
		<?php
			$pt = 0;
			$t = 0;
		?>
		<?php $__currentLoopData = $pjk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td><?php echo e($pk->jenis); ?></td>
				<td><?php echo e($pk->trans); ?></td>
				<td>Rp <?php echo e(Rupiahd($pk->t_pajak)); ?></td>
				<td>Rp <?php echo e(Rupiahd($pk->total_b)); ?></td>

			</tr>
			<?php
				$pt += $pk->t_pajak;
				$t += $pk->trans
			?>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<th>Total</th>
			<th><?php echo e($t); ?></th>
			<th style="text-transform: capitalize;">
				Rp <?php echo e(Rupiah($pt)); ?>

			</th>
			<th style="text-transform: capitalize;">
				Rp <?php echo e(Rupiah($total_b)); ?>

			</th>

		</tr>									
	</table>
</body>
</html>


