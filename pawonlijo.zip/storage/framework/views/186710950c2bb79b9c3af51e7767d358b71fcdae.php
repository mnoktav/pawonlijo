<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/kasir/print-nota-p.blade.php */ ?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Nota</title>
	<style>
		@page{ 
			size: 164pt <?php echo e((5*30)+(count($detail)*2*35)+(280)); ?>pt;
			margin: 0;
		}
		<?php if(Request::segment(2) == 'nota'): ?>
			a{
				visibility: hidden;
			}
		<?php endif; ?>
	</style>
</head>
<body>
	<div class="container" style="padding: 3mm; width: 53mm;">
		<div class="print">
			<div class="header" style="text-align: center;">
				<h3>Pawon Lijo</h3>
				<p style="margin-top: -1%; padding-bottom: 20px; border-bottom: 2px dashed black; font-size: 13px;">
					<?php echo e(session('login')['nama_booth']); ?> <br>
					<?php echo e($booth->alamat_booth); ?>, <?php echo e($booth->kota_booth); ?>

				</p>
			</div>

			<table style="margin-bottom: 20px;">
				<?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<tr style="height: 20px">
					<?php $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<?php if($d->id_produk == $p->id): ?>
							<td colspan="3"><?php echo e($p->nama_makanan); ?></td>
						<?php endif; ?>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				</tr>
				<tr  style="height: 20">
					<td width="70px">Rp <?php echo e(Rupiahd($d->harga_satuan)); ?></td>
					<td width="40px" style="padding-bottom: 5px">x <?php echo e($d->jumlah); ?></td>
					<td>Rp <?php echo e(Rupiahd($d->harga_satuan*$d->jumlah)); ?></td>
				</tr>
				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<tr>
					<td width="60%" colspan="2" style="padding-top: 20px">Subtotal</td>
					<td width="40%" style="padding-top: 20px">Rp <?php echo e(Rupiahd($nota->subtotal)); ?></td>
				</tr>
				<tr>
					<td width="60%" colspan="2">Potongan</td>
					<td width="40%">Rp <?php echo e(Rupiahd($nota->potongan)); ?></td>
				</tr>
				<tr >
					<td width="60%" colspan="2">Total</td>
					<td width="40%">Rp <?php echo e(Rupiahd($nota->total)); ?></td>
				</tr>
				<tr>
					<td colspan="2" style="padding-top: 20px">Bayar</td>
					<td style="padding-top: 20px">Rp <?php echo e(Rupiahd($nota->bayar)); ?></td>
				</tr>
				<tr>
					<td colspan="2">Kembali</td>
					<td>Rp <?php echo e(Rupiahd($nota->kembali)); ?></td>
				</tr>
			</table>
			<div class="" style="padding-top: 20px; border-top: 2px dashed black; height: 40px;">
				<?php echo e($nota->id); ?> <br>
				<?php echo e(date('d/m/Y H:i',strtotime($nota->created_at))); ?><br>
				<?php echo e($nota->jenis); ?> 
				<?php echo e($nota->kode != null ? '('.$nota->kode.')' : null); ?>

			</div>
			<div align="center" style="height: 40px; margin-top: 30px;">
				<p>Thank you <?php echo e($nota->nama_pembeli); ?>!</p>
			</div>
		</div>
	</div>
	
	
</body>
</html>