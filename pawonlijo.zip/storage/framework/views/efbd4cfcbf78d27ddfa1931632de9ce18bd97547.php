<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/admin/booth-edit.blade.php */ ?>
<?php $__env->startSection('css'); ?>
	<style>
		.form .form-group{
			margin: 1.2rem 0;
			padding: 0;
		}
		.form label{
			text-transform: uppercase;
		}
		.form input, .form textarea{
			border: 1px solid #aaaaaa;
		}
	</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>	
	<div class="page-inner">
		<div class="page-header">
			<h4 class="page-title">Booth PawonLijo</h4>
			<ul class="breadcrumbs">
				<li class="nav-home">
					<a href="<?php echo e(route('admin.dashboard')); ?>">
						<i class="flaticon-home"></i>
					</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a>Booth</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a>Booth PawonLijo</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a>Edit</a>
				</li>
			</ul>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-body">
						<div class="row">
							<div class="col-lg-6">
								<h4><b><?php echo e($booth->nama_booth); ?>, <?php echo e($booth->kota_booth); ?></b></h4>
								<small class="text-secondary"><b>#PLJBG1</b></small>
							</div>
							<div class="col-lg-6 text-right">
								<a class="btn btn-sm btn-rounded btn-primary" href="<?php echo e(route('admin.detail-booth',$booth->id_booth)); ?>">
									<span class="btn-label">
										<i class="fas fa-angle-left"></i>
									</span>
									Kembali
								</a>
							</div>
						</div>
						<div class="separator-solid"></div>
						<ul class="nav nav-pills nav-primary nav-pills-no-bd" id="pills-tab-without-border" role="tablist">
							<li class="nav-item">
								<a class="nav-link <?php echo e(session()->get('msg') == 'booth' || session()->get('msg') == "" ? 'active' : null); ?>" id="pills-home-tab-nobd" data-toggle="pill" href="#pills-home-nobd" role="tab" aria-controls="pills-home-nobd" aria-selected="true">Booth</a>
							</li>
							<li class="nav-item">
								<a class="nav-link <?php echo e(session()->get('msg') == 'akun' ? 'active' : null); ?>" id="pills-akun-tab-nobd" data-toggle="pill" href="#pills-akun-nobd" role="tab" aria-controls="pills-akun-nobd" aria-selected="false">Akun</a>
							</li>
							<li class="nav-item">
								<a class="nav-link <?php echo e(session()->get('msg') == 'pegawai' ? 'active' : null); ?>" id="pills-kasir-tab-nobd" data-toggle="pill" href="#pills-kasir-nobd" role="tab" aria-controls="pills-kasir-nobd" aria-selected="false">Kasir</a>
							</li>
						</ul>
						<div class="row" style="margin-top: 1rem;">
							<div class="col-md-12">
								<div class="tab-content" id="pills-without-border-tabContent">
									<div class="tab-pane fade show <?php echo e(session()->get('msg') == 'booth' || session()->get('msg') == "" ? 'active' : null); ?>" id="pills-home-nobd" role="tabpanel" aria-labelledby="pills-home-tab-nobd">
										<div class="card" style="border: 1px solid #dddddd;">
											<div class="card-body">
												<form action="<?php echo e(route('admin.update-booth')); ?>" method="POST">
													<?php echo csrf_field(); ?>
													<h4><b><span class="fas fa-info-circle text-warning"></span>&nbsp; INFORMASI BOOTH</b></h4>
													<div class="separator-solid"></div>
													<div class="form col-md-8 col-12" style="padding: 0;">
														<div class="form-group">
															<label for="id-booth">ID Booth</label>
															<input type="text" class="form-control" id="id_booth" value="<?php echo e($booth->id_booth); ?>" name="id_booth" readonly="">
														</div>
														<div class="form-group">
															<label for="nama-booth">Nama Booth</label>
															<input type="text" class="form-control" id="nama_booth" name="nama_booth" value="<?php echo e($booth->nama_booth); ?>">
														</div>
														<div class="form-group">
															<label for="alamat-booth">Alamat Booth</label>
															<textarea class="form-control" name="alamat_booth" id="alamat_booth"><?php echo e($booth->alamat_booth); ?></textarea>
														</div>
														<div class="form-group">
															<label for="kota">Kota</label>
															<input type="text" class="form-control" name="kota" id="kota" value="<?php echo e($booth->kota_booth); ?>">
														</div>
														<div class="row">
															<div class="col-md-6">
																<div class="form-group">
																	<label for="jam_buka">Jam Buka</label>
																	<input type="time" class="form-control" name="jam_buka" id="jam_buka" value="<?php echo e($booth->jam_buka); ?>">
																</div>
															</div>
															<div class="col-md-6">
																<div class="form-group">
																	<label for="jam_tutup">Jam Tutup</label>
																	<input type="time" class="form-control" name="jam_tutup" id="jam_tutup" value="<?php echo e($booth->jam_tutup); ?>">
																</div>
															</div>
														</div>
														<div class="form-group">
															<label for="nomor">Nomor Telephone</label>
															<input type="text" class="form-control" name="nomor" id="nomor" value="<?php echo e($booth->telepon_booth); ?>" onkeypress="return NumberOnly(event)">
														</div>
														<div class="text-right">
															<input type="submit" name="update_booth" value="Update" class="btn btn-warning">
														</div>	
													</div>
												</form>
											</div>
										</div>
									</div>
									<div class="tab-pane fade show <?php echo e(session()->get('msg') == 'akun' ? 'active' : null); ?>" id="pills-akun-nobd" role="tabpanel" aria-labelledby="pills-akun-tab-nobd">
										<div class="card" style="border: 1px solid #dddddd;">
											<div class="card-body">
												<h4><b><span class="fas fa-user-lock text-warning"></span>&nbsp; AKUN</b></h4>
												<div class="separator-solid"></div>
												<div class="form col-md-8 col-12" style="padding: 0;">
													<div class="form-group">
														<label for="username">username</label>
														<input type="text" class="form-control" id="username" disabled="" value="<?php echo e($booth->username_booth); ?>">

													</div>
													<div class="row">
														<div class="col-md-10">
															<div class="form-group">
																<label>Password</label>
																<input type="password" class="form-control" value="<?php echo e(Crypt::decryptString($booth->password_booth)); ?>" readonly="" id="password">
															</div>
														</div>
														<div class="col-md-1 mt-4 pt-2">
															<div class="form-group">
																<button class="btn btn-sm btn-primary btn-rounded" onclick="LihatPassword()">Lihat</button>
															</div>
														</div>
													</div>
												</div>
												<br>
												<h4><b><span class="fas fa-user-edit text-warning"></span>&nbsp; UPDATE AKUN</b></h4>
												<div class="separator-solid"></div>
												<div class="form col-md-8 col-12" style="padding: 0;">
													<form action="<?php echo e(route('admin.update-booth')); ?>" method="POST">
														<?php echo csrf_field(); ?>
														<div class="form-group <?php echo e($errors->has('username_booth') ? 'has-error' : null); ?>">
															<label for="username">username</label>
															<input type="text" class="form-control" id="username_booth" name="username_booth" value="<?php echo e($booth->username_booth); ?>">
															<input type="hidden" name="id_booth" value="<?php echo e($booth->id_booth); ?>">
															<?php if($errors->has('username_booth')): ?>
																<span class="help-block text-danger">
																	<?php echo e($errors->first('username_booth')); ?>

																</span>
															<?php endif; ?>
														</div>
														<div class="form-group <?php echo e($errors->has('password_booth') ? 'has-error' : null); ?>">
															<label for="password_booth">Password Baru</label>
															<input type="password" class="form-control" id="password_booth" name="password_booth">
															<?php if($errors->has('password_booth')): ?>
																<span class="help-block text-danger">
																	<?php echo e($errors->first('password_booth')); ?>

																</span>
															<?php endif; ?>
														</div>
														<div class="form-group <?php echo e($errors->has('re_pass') ? 'has-error' : null); ?>">
															<label for="repass">Ketik Ulang Password Baru</label>
															<input type="password" class="form-control" id="re_pass" name="repass">
															<?php if($errors->has('re_pass')): ?>
																<span class="help-block text-danger">
																	<?php echo e($errors->first('re_pass')); ?>

																</span>
															<?php endif; ?>
														</div>
														<div class="text-right">
															<input type="submit" value="Update" name="update_akun" class="btn btn-warning">
														</div>
													</form>
												</div>
											</div>
										</div>
									</div>
									<div class="tab-pane fade show <?php echo e(session()->get('msg') == 'pegawai' ? 'active' : null); ?>" id="pills-kasir-nobd" role="tabpanel" aria-labelledby="pills-kasir-tab-nobd">
										<div class="card" style="border: 1px solid #dddddd;">
											<div class="card-body">
												<div class="row">
													<div class="col-md-6">
														<h4 class="mt-2"><b><span class="fas fa-info-circle text-warning"></span>&nbsp; INFORMASI KASIR</b></h4>
													</div>
													<div class="col-md-6 text-right">
														<button class="btn btn-sm btn-primary" data-toggle="modal" data-target="#myModal">Tambah Kasir</button>
													</div>
												</div>
												
												<div class="separator-solid"></div>
												<?php if($jumlah_kasir>=1): ?>
												<form action="<?php echo e(route('admin.update-booth')); ?>" method="POST">
													<?php echo csrf_field(); ?>
													<div class="form col-md-8 col-12" style="padding: 0;">
														<?php $__currentLoopData = $kasirs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kasir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
															<div class="form-group">
																<label for="nama-kasir1">Nama Kasir</label>
																<input type="text" class="form-control" id="nama-kasir1" name="nama_kasir[]" value="<?php echo e($kasir->nama_kasir); ?>">
																<input type="hidden" name="id_kasir[]" value="<?php echo e($kasir->id); ?>">
																<input type="hidden" name="id_booth[]" value="<?php echo e($booth->id_booth); ?>">
																
															</div>
															<div class="form-group">
																<label for="alamat-kasir1">Alamat Kasir</label>
																<textarea class="form-control" id="alamat-kasir1" name="alamat_kasir[]"><?php echo e($kasir->alamat_kasir); ?></textarea>
															</div>
															<div class="form-group">
																<label for="no-kasir1">Telephone Kasir</label>
																<input type="text" class="form-control" id="no-kasir1" name="telp_kasir[]" value="<?php echo e($kasir->telp_kasir); ?>" onkeypress="return NumberOnly(event)">
															</div>
															<a href="<?php echo e(route('admin.delete-kasir',$kasir->id)); ?>" class="btn btn-danger btn-sm hapus-kasir" data-id="<?php echo e($kasir->id); ?>">Hapus</a>
															<div class="separator-solid"></div>
														<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
														<div class="text-right">
															<input type="submit" name="update_kasir1" value="Update" class="btn btn-warning">
														</div>
													</div>
												</form>
												<?php else: ?>
													<div class="text-center m-4">
														<h3>Belum Ada Informasi Kasir</h3>
													</div>
												<?php endif; ?>
											</div>
										</div>
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="modal" id="myModal">
	  	<div class="modal-dialog">
	    	<div class="modal-content">
	      		<div class="modal-header">
	        		<h4 class="modal-title">Tambah Data Kasir</h4>
	        		<button type="button" class="close" data-dismiss="modal">&times;</button>
	      		</div>
	      		<form action="<?php echo e(route('admin.update-booth')); ?>" method="POST">
		      		<div class="modal-body">
						<?php echo csrf_field(); ?>
						<div class="form col-12" style="padding: 0;">
							<div class="form-group">
								<label for="nama-kasir1">Nama Kasir</label>
								<input type="text" class="form-control" id="nama-kasir1" name="nama_kasir[]" value="">
								<input type="hidden" name="id_booth[]" value="<?php echo e($booth->id_booth); ?>">
								
							</div>
							<div class="form-group">
								<label for="alamat-kasir1">Alamat Kasir</label>
								<textarea class="form-control" id="alamat-kasir1" name="alamat_kasir[]"></textarea>
							</div>
							<div class="form-group">
								<label for="no-kasir1">Telephone Kasir</label>
								<input type="text" class="form-control" id="no-kasir1" name="telp_kasir[]" value="" onkeypress="return NumberOnly(event)">
							</div>
						</div>
		      		</div>
		      		<div class="modal-footer">
		        		<button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
		        		<input type="submit" name="update_kasir1" value="Tambah" class="btn btn-success">
		      		</div>
	      		</form>
	    	</div>
	  	</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
	<script>
		function LihatPassword() {
		  	var x = document.getElementById("password");
		  	if (x.type === "password") {
		    	x.type = "text";
			 } else {
			    x.type = "password";
			}
		}
	</script>
	<script>
		$(document).ready(function(){
		    $('.hapus-kasir').on('click', function(e){
		        e.preventDefault(); //cancel default action

		        //Recuperate href value
		        var href = $(this).attr('href');
		        var message = $(this).data('confirm');

		        //pop up
		        swal({
		            title: "Apakah anda yakin?",
		            text: message, 
		            icon: "warning",
		            buttons: true,
		            dangerMode: true,
		        })
		        .then((willDelete) => {
		          if (willDelete) {
		            window.location.href = href;
		          }
		        });
		    });
		});
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin/master-d', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>