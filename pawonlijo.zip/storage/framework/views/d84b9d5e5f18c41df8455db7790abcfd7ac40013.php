<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/admin/sales-detail.blade.php */ ?>
<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>	
	<div class="page-inner">
		<div class="page-header">
			<h4 class="page-title">Data Penjualan PawonLijo</h4>
			<ul class="breadcrumbs">
				<li class="nav-home">
					<a href="<?php echo e(route('admin.dashboard')); ?>">
						<i class="flaticon-home"></i>
					</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a>Data Penjualan</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a>Detail</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a><?php echo e($sale->id); ?></a>
				</li>
			</ul>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-body">
						<div class="row">
							<div class="col-md-6">
								<h4><b><?php echo e($sale->id); ?></b></h4>
								<small><?php echo e($booth->nama_booth); ?>, <?php echo e($booth->kota_booth); ?> (<?php echo e($booth->id_booth); ?>)</small><br>
							</div>
							<div class="col-md-6 text-right text-light">
								<a class="btn btn-sm btn-rounded btn-primary" onclick="window.history.back()">
									<span class="btn-label">
										<i class="fas fa-angle-left"></i>
									</span>
									Kembali
								</a>
							</div>
						</div>
						<div class="card border mt-4">
							<div class="card-body">
								<div class="row mb-3">
									<div class="col-md-5">
										<h5><b>Nama Pembeli</b> : <?php echo e($sale->nama_pembeli); ?></h5>
										<h5>
											<b>Jenis Transaksi</b> : 
											<?php echo e($sale->jenis); ?>

											<?php if($sale->kode != null): ?>
											 	(<?php echo e($sale->kode); ?>)
											<?php endif; ?>
										</h5>
									</div>
									<div class="col-md-5">
										<h5><b>Tanggal</b> : <?php echo e(date('d/m/Y H:i',strtotime($sale->created_at))); ?></h5>
										<?php if($sale->status == 1): ?>
										<h5><b>Status</b> : Sukses<i class="fas fa-check ml-2 text-success"></i></h5>
										<?php elseif($sale->status == 2): ?>
										<h5><b>Status</b> : Pending<i class="fas fa-check ml-2 text-muted"></i></h5>
										<?php else: ?>
										<h5><b>Status</b> : Batal<i class="fas fa-times ml-2 text-danger"></i></h5>
										<?php endif; ?>
										<?php if($sale->status == 0): ?>
										<p><b>Alasan Pembatalan : </b> <?php echo e($sale->keterangan); ?></p>
										<?php elseif($sale->jenis == 'Pesanan'): ?>
										<p><b>Keterangan : </b> <?php echo e($sale->keterangan); ?></p>
										<?php endif; ?>
									</div>
									<div class="col-md-2">
										<div class="text-right">
											<a class="btn btn-secondary btn-sm mr-2" href="<?php echo e(asset('storage/'.$sale->id.'.pdf')); ?>" target="_blank">
												<span class="btn-label">
													<i class="fas fa-print"></i>
												</span>
												Nota
											</a>
										</div>
									</div>
								</div>
								<div class="table-responsive">
									<table class="table table-striped">
										<thead class="bg-dark text-light">
											<tr>
												<th>Nama Produk</th>
												<th>Harga Satuan</th>
												<th>Jumlah</th>
												<th>Sub Total</th>
											</tr>
										</thead>
										<tbody>
											<?php $__currentLoopData = $detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td><?php echo e($detail->nama_makanan); ?></td>
												<td>Rp <?php echo e(Rupiah($detail->harga_satuan)); ?></td>
												<td><?php echo e($detail->jumlah); ?></td>
												<td>Rp <?php echo e(Rupiah($detail->harga_satuan*$detail->jumlah)); ?></td>
											</tr>
											<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											<tr>
												<td colspan="3"><b>SUBTOTAL</b></td>
												<td>Rp <?php echo e(Rupiah($sale->subtotal)); ?></td>
											</tr>
											<tr>
												<td colspan="3"><b>DISCOUNT BOOTH</b></td>
												<td>Rp <?php echo e(Rupiah($sale->potongan)); ?></td>
											</tr>
											<tr>
												<td colspan="3"><b>TOTAL</b></td>
												<td><b> Rp <?php echo e(Rupiah($sale->total)); ?></b></td>
											</tr>
											<tr>
												<td colspan="3"><b>TOTAL BERSIH (PAJAK <?php echo e($sale->pajak); ?>%)</b></td>
												<td><b>Rp <?php echo e(Rupiah($sale->total_bersih)); ?> &nbsp;&nbsp;&nbsp;(Rp <?php echo e(Rupiah($sale->subtotal*$sale->pajak/100)); ?>)</b></td>
											</tr>
											<tr>
												<td><b>BAYAR</b></td>
												<td>Rp <?php echo e(Rupiah($sale->bayar)); ?></td>
											</tr>
											<tr>
												<td><b>KEMBALI</b></td>
												<td>Rp <?php echo e(Rupiah($sale->kembali)); ?></td>
											</tr>
										</tbody>
									</table>
								</div>
								<div class="text-center">
									<button type="button" class="btn btn-sm btn-rounded btn-danger <?php echo e($sale->status == 0 || $sale->jenis == 'Pesanan' || $sale->status == 1 ? 'd-none' : null); ?>" data-toggle="modal" data-target=".bd-example-modal-sm ">Batalkan Transaksi</button>
									<a href="<?php echo e(route('admin.transaksi-update-pesanan', $sale->id)); ?>" class="btn btn-sm btn-rounded btn-success <?php echo e($sale->status != 2 ? 'd-none' : null); ?>">Transaksi Selesai</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<div class="modal fade bd-example-modal-sm mt-4" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
	  	<div class="modal-dialog modal-sm">
	    	<div class="modal-content">
	    		<form action="<?php echo e(route('kasir.transaksi-batal')); ?>" method="POST">
	    			<?php echo csrf_field(); ?>
		      		<div class="modal-header">
				        <h5 class="modal-title">Transaksi Batal</h5>
				        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
				          <span aria-hidden="true">&times;</span>
				        </button>
				    </div>
				    <div class="modal-body">
				        <div class="form-group">
				        	<label for="">ID Transaksi</label>
				        	<input type="text" class="form-control" name="id" value="<?php echo e($sale->id); ?>" readonly>
				        </div>
				        <div class="form-group">
				        	<label for="">Alasan Pembatalan</label>
				        	<textarea name="keterangan" class="form-control" required=""></textarea>
				        </div>
				        <p class="text-danger p-2">Transaksi yang sudah dibatalkan tidak bisa dikembalikan!</p>
				    </div>
				    <div class="modal-footer">
				        <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
				        <input type="submit" class="btn btn-primary btn-sm" name="batal" value="Update">
				    </div>
			    </form>
	    	</div>
	  	</div>
	</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/master-d', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>