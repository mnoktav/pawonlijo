<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/admin/booth-detail-home.blade.php */ ?>
<?php $__env->startSection('content2'); ?>	
	
	<div class="card" style="border: 1px solid #dddddd;">
		<div class="card-body">
			<h4><b><span class="fas fa-info-circle text-warning"></span>&nbsp; INFORMASI BOOTH</b></h4>
			<div class="separator-solid"></div>
			<div class="table-responsive">
				<table class="table table-striped" style="padding: 0px !important;">
					<tr>
						<td width="20%">Nama Booth</td>
						<td width="1%">:</td>
						<td><?php echo e($booth->nama_booth); ?></td>
					</tr>
					<tr>
						<td>ID Booth</td>
						<td>:</td>
						<td><?php echo e($booth->id_booth); ?></td>
					</tr>
					<tr>
						<td>Alamat Booth</td>
						<td>:</td>
						<td><?php echo e($booth->alamat_booth); ?></td>
					</tr>
					<tr>
						<td>Jam Operasional</td>
						<td>:</td>
						<td><?php echo e(date('H:i',strtotime($booth->jam_buka))); ?> - <?php echo e(date('H:i',strtotime($booth->jam_tutup))); ?> WIB</td>
					</tr>
					<tr>
						<td>Nomor Telephone</td>
						<td>:</td>
						<td><?php echo e($booth->telepon_booth); ?></td>
					</tr>
					<tr>
						<td>Username Booth</td>
						<td>:</td>
						<td><?php echo e($booth->username_booth); ?></td>
					</tr>
					<tr>
						<td>Password Booth</td>
						<td>:</td>
						<td>
							<div class="row">
								<div class="col-md-3">
									<input type="password" class="form-control" value="<?php echo e(Crypt::decryptString($booth->password_booth)); ?>" readonly="" id="password">
								</div>
								<div class="col-md-1">
									<button class="btn btn-sm btn-primary btn-rounded  mt-1" onclick="LihatPassword()">Lihat</button>
								</div>
							</div>
							
						</td>
					</tr>
				</table>
			</div>
			<br>
			<h4><b><span class="fas fa-handshake text-warning"></span>&nbsp; INFORMASI JENIS TRANSAKSI</b></h4>
			<div class="separator-solid"></div>
			<div class="table-responsive">
				<table class="table table-striped">
					<tr>
						<th>No.</th>
						<th>Jenis Transaksi</th>
						<th>Pajak</th>
						<th>Status</th>
						<th>Action</th>
					</tr>
					<?php
						$a = 1;
					?>
					<?php $__currentLoopData = $jenis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td><?php echo e($a++); ?></td>
						<td><?php echo e($j->jenis_transaksi); ?></td>
						<?php if($j->pajak == 0): ?>
							<td>-</td>
						<?php else: ?>
							<td><?php echo e($j->pajak); ?> %</td>
						<?php endif; ?>
						<?php if($j->status == 1): ?>
							<td>Aktif</td>
						<?php else: ?>
							<td>Non-Aktif</td>
						<?php endif; ?>
						<?php if($j->status == 1): ?>
							<td>
								<a href="/admin/booth/booth-pawonlijo/transaksi/<?php echo e($j->id); ?>/0" class="btn btn-xs btn-warning">Non-aktifkan</a>
							</td>
						<?php else: ?>
							<td><a href="/admin/booth/booth-pawonlijo/transaksi/<?php echo e($j->id); ?>/1" class="btn btn-xs btn-success">Aktifkan</a></td>
						<?php endif; ?>
					</tr>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				</table>
			</div>
			<br>
			<h4><b><span class="fas fa-chalkboard-teacher text-warning"></span>&nbsp; INFORMASI PEGAWAI</b></h4>
			<div class="separator-solid"></div>
			<div class="table-responsive">
				<?php
					$i = 1;
				?>
				<?php if($jumlah_kasir > 0): ?>
					<?php $__currentLoopData = $kasirs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kasir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<table class="table table-striped">
							<tr>
								<td width="20%">Nama Pegawai <?php echo e($i++); ?></td>
								<td width="1%">:</td>
								<td><?php echo e($kasir->nama_kasir); ?></td>
							</tr>
							<tr>
								<td>Alamat Pegawai</td>
								<td>:</td>
								<td><?php echo e($kasir->alamat_kasir); ?></td>
							</tr>
							<tr>
								<td>Nomor Telp. Pegawai</td>
								<td>:</td>
								<td><?php echo e($kasir->telp_kasir); ?></td>
							</tr>
						</table>
					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
				<?php else: ?>
					<h4 align="center" class="mt-4 mb-4">Belum tersedia kasir untuk booth ini.</4>
				<?php endif; ?>
				
			</div>
		</div>
	</div>
	
	<div class="modal fade bd-example-modal-sm mt-4" tabindex="-1" role="dialog" aria-labelledby="mySmallModalLabel" aria-hidden="true">
	  	<div class="modal-dialog modal-sm">
	    	<div class="modal-content">
	    		<form action="<?php echo e(route('admin.pajak-booth-transaksi')); ?>" method="POST">
	    			<?php echo csrf_field(); ?>
		      		<div class="modal-header">
				        <h5 class="modal-title">Edit Transaksi</h5>
				        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
				          <span aria-hidden="true">&times;</span>
				        </button>
				    </div>
				    <div class="modal-body">
				        <div class="form-group">
				        	<label for="">Nama Transaksi</label>
				        	<input type="text" class="form-control" id="nama_transaksi" name="nama_transaksi" value="" readonly>
				        	<input type="hidden" class="form-control" name="id" id="id_jenis" value="">
				        </div>
				        <div class="form-group">
				        	<label for="">Pajak</label>
				        	<input type="number" min="0" class="form-control" name="pajak" id="pajak" value="">
				        </div>
				    </div>
				    <div class="modal-footer">
				        <button type="button" class="btn btn-secondary btn-sm" data-dismiss="modal">Close</button>
				        <input type="submit" class="btn btn-primary btn-sm" name="batal" value="Update">
				    </div>
			    </form>
	    	</div>
	  	</div>
	</div>

<?php $__env->stopSection(); ?>




<?php echo $__env->make('admin/booth-detail', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>