<?php /* E:\Semester 8\TA\Project\pawonlijo\resources\views/admin/booth.blade.php */ ?>
<?php $__env->startSection('css'); ?>
	<style>
		.nama_kasir{
			margin:0;
		}
	</style>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>	
	<div class="page-inner">
		<div class="page-header">
			<h4 class="page-title">Booth PawonLijo</h4>
			<ul class="breadcrumbs">
				<li class="nav-home">
					<a href="<?php echo e(route('admin.dashboard')); ?>">
						<i class="flaticon-home"></i>
					</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a>Booth</a>
				</li>
				<li class="separator">
					<i class="flaticon-right-arrow"></i>
				</li>
				<li class="nav-item">
					<a>Booth PawonLijo</a>
				</li>
			</ul>
		</div>
		<div class="row">
			<div class="col-md-12">
				<div class="card">
					<div class="card-body">
						<div class="row">
							<div class="col-md-12">
								<div class="form-group" style="padding: 0;">
									<div class="input-icon">
										<input type="text" class="form-control" placeholder="Search for..." id="search" onkeyup="Search()" style="border: 1px #cccccc solid;">
										<span class="input-icon-addon">
											<i class="fa fa-search"></i>
										</span>
									</div>
								</div>
							</div>
						</div>
						<div class="separator-solid"></div>
						<div class="row">
							<?php $__currentLoopData = $booths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $booth): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<div class="col-md-4 target ">
								<div class="shadow-none card card-post card-round full-height" style="border: 1px #cccccc solid; <?php echo e($booth->status == 0 ? 'background-color: #f2f2f2' : null); ?>">
									<div class="card-body">
										<div class="d-flex">
											<div class="avatar">
												<?php if($booth->status != 0): ?>
													<span class="fas fa-store fa-2x mt-2" style="color: orange;"></span>
												<?php else: ?>
													<span class="fas fa-store fa-2x mt-2" style="color: grey;"></span>
												<?php endif; ?>
												
											</div>
											<div class="info-post ml-2">
												<p class="username"><?php echo e($booth->nama_booth); ?></p>
												<p class="date text-muted">
													<?php echo e($booth->id_booth); ?>

													<?php if($booth->status == 0): ?>
														(Nonaktif)
													<?php endif; ?>
												</p>
											</div>
										</div>
										<div class="separator-solid"></div>
										<div class="row">
											<div class="col-md-12">	
												<h6><b>Alamat Booth : </b></h6>
												<p><?php echo e($booth->alamat_booth); ?>, <?php echo e($booth->kota_booth); ?></p>
												<h6><b>Jam Operasional : </b></h6>
												<p><?php echo e(date('H:i',strtotime($booth->jam_buka))); ?> - <?php echo e(date('H:i',strtotime($booth->jam_tutup))); ?> WIB</p>
											</div>
											<div class="col-md-12">
												<h6><b>Pegawai : </b></h6>
												<?php
													$i = 1;
												?>
												<?php $__currentLoopData = $kasirs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $kasir): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
												<?php if($kasir->id_booth == $booth->id_booth): ?>
													<p class="nama_kasir"><?php echo e($i++.'.'.' '.$kasir->nama_kasir); ?></p>
												<?php endif; ?>
												<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
											</div>
										</div>
									</div>
									<div class="card-footer">
										<div class="text-center">
											<a href="<?php echo e(route('admin.detail-booth', $booth->id_booth)); ?>" class="btn btn-primary btn-rounded btn-sm">Detail Booth</a>
										</div>
									</div>
									
								</div>
							</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>
					</div>
				</div>
			</div>
		</div>
	</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
	<script>
		function Search() {
		  var input = document.getElementById("search");
		  var filter = input.value.toLowerCase();
		  var nodes = document.getElementsByClassName('target');

		  for (i = 0; i < nodes.length; i++) {
		    if (nodes[i].innerText.toLowerCase().includes(filter)) {
		      nodes[i].style.display = "block";
		    } else {
		      nodes[i].style.display = "none";
		    }
		  }
		}
	</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin/master-d', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>