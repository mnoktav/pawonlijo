<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Top_Product extends Model
{
    protected $table = "view_top_product";
}
