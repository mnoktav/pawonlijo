<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class View_Transaksi extends Model
{
    protected $table = "view_transaksi";
    public $incrementing = false;
}
