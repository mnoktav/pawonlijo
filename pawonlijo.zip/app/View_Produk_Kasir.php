<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class View_Produk_Kasir extends Model
{
    protected $table = "view_produk_kasir";
    public $incrementing = false;
}
